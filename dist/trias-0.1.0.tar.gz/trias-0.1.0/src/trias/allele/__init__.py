# src/trias/allele/__init__.py
from .extract import vcf_alleles_cmd
from .report_dntre import report_dntre_cmd

__all__ = ["vcf_alleles_cmd", "report_dntre_cmd"]
