# TRiAs

TRiAs (Tandem Repeat identification from Assemblies) is a toolkit for
extracting and analyzing tandem repeat alleles from genome assemblies.

## Installation

```bash
pip install trias

